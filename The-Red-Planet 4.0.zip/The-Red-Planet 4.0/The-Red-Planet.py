from ursina import *
from time import sleep


app = Ursina()

speed1 = 2.5
speed = 2.5

def update():
    global speed
    
    
    hit_info = player.intersects()
    
    
    if held_keys['w']:
        player.y += speed * time.dt
        player.texture = "sprite1runB.png"
        if hit_info.hit:
            player.y -= 0.3
            speed = 0
            sleep(0.2)
        else:
            speed = speed1
    
    
    if held_keys['s']:
        player.y -= speed * time.dt
        player.texture = "sprite1runF.png"
        if hit_info.hit:
            player.y += 0.3
            speed = 0
            sleep(0.2)
        else:
            speed = speed1
    
    if held_keys['d']:
        player.x += speed * time.dt
        player.texture = "sprite1runR.png"
        if hit_info.hit:
            player.x -= 0.3
            speed = 0
            sleep(0.2)
        else:
            speed = speed1
    
    if held_keys['a']:
        player.x -= speed * time.dt
        player.texture = "sprite1runL.png"
        if hit_info.hit:
            player.x += 0.3
            speed = 0
            sleep(0.2)
        else:
            speed = speed1
    
    if player.y > 4:
        player.y -= 0.1
        
    if player.y < -4:
        player.y += 0.1
        
    if player.x > 6:
        player.x -= 0.1
        
    if player.x < -6:
        player.x += 0.1
     
    if held_keys['e']:
        print("e")
    
    
    if held_keys['escape']:
        quit()
    
    
    

player = Entity(model = "quad", texture = "sprite1still.png", position = (0, -3, 0), scale = 2, collider = "box")

tree = Entity(model = "quad", texture = "Tree.png", position = (4.3, 0, .9), scale = 3)

level1map = Entity(model = "quad", texture = "map1st.png", position = (0, 2, 1), scale = 13)

rivINT = Entity(model = "cube", position = (0,1.5,0), scale = (30,2.7,2), rotation = -7, collider = "mesh")

rivINT.visible = False

ctrls = Text(text = "w, a, s, d\nto move\nE to use", position = (-.87, 0, 0))

RB = Entity(model = "quad", texture = "Button.png", position = (0,-2,0))

RBint = Entity(model = "quad", position = (0,-2,0), scale = .001)

Text1 = Text(text = "Press E to Launch", color = color.red, position = (-.1,-.3,0))

app.run()


