from ursina import *

app = Ursina()

def update():
    
    
    if held_keys['w']:
        player.y += 0.1
     
     
    if held_keys['s']:
        player.y -= 0.1
    
    
    if held_keys['d']:
        player.x += 0.1
    
    
    if held_keys['a']:
        player.x -= 0.1
    
    
    
    if held_keys['escape']:
        quit()


player = Entity(model = "quad", texture = "", color = color.red, position = (0, 0, 0))


app.run()