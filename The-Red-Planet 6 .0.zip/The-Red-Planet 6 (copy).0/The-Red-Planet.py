from ursina import *
from time import sleep
from random import randint

#game vars

app = Ursina()

speed1 = 2.5
speed = 2.5
speed2 = 2.5
speed3 = 2.5

viewheight1 = 4
viewwidth1 = 6
viewheight2 = -4
viewwidth2 = -6

zombiespeed = 0.1

weapon = 0

pTxTr1 = "sprite1runB.png"
pTxTr2 = "sprite1runF.png"
pTxTr3 = "sprite1runR.png"
pTxTr4 = "sprite1runL.png"

useKey = 'e'

#update func containing movement, e = use, and game event
    

def update():
    global speed
    global a,b
    global speed2
    
    
    hit_info = player.intersects()
    hit_info1 = player.intersects(zombie1)
    
    if held_keys['w']:
        player.y += speed * time.dt
        player.texture = pTxTr1
        if hit_info.hit:
            player.y -= 0.3
            speed = 0
            sleep(0.2)
        else:
            speed = speed1
    
    
    if held_keys['s']:
        player.y -= speed * time.dt
        player.texture = pTxTr2
        if hit_info.hit:
            player.y += 0.3
            speed = 0
            sleep(0.2)
        else:
            speed = speed1
    
    if held_keys['d']:
        player.x += speed2 * time.dt
        player.texture = pTxTr3
        if hit_info.hit:
            player.x -= 0.3
            speed = 0
            sleep(0.2)
        else:
            speed2 = speed3
    
    if held_keys['a']:
        player.x -= speed2 * time.dt
        player.texture = pTxTr4
        if hit_info.hit:
            player.x += 0.3
            speed = 0
            sleep(0.2)
        else:
            speed2 = speed3
    
    if player.y > viewheight2:
        player.y -= 0.1
        
    if player.y < viewheight1:
        player.y += 0.1
        
    if player.x > viewwidth2:
        player.x -= 0.1
        
    if player.x < viewwidth1:
        player.x += 0.1
     
    if held_keys[useKey]:
        
        tree.texture = "Tree2.png"
        level1map.texture = "map2nd.png"
        invoke(redP, delay = 5)
        
    if zombie1.x < -8:
        zombie1.x = 6
        zombie1.y = randint(-4, 4)
     
    if hit_info1.hit:
        quit()
    
    
    zombie1.x -= zombiespeed
    
    if held_keys['escape']:
        quit()



    
    
        
    
    
#all the entities    

player = Entity(model = "quad", texture = "sprite1still.png", position = (0, -3, 0), scale = 2, collider = "box")

tree = Entity(model = "quad", texture = "Tree.png", position = (4.3, 0, .9), scale = 3)

level1map = Entity(model = "quad", texture = "map1st.png", position = (0, 2, 1), scale = 13)

rivINT = Entity(model = "cube", position = (0,1.5,0), scale = (30,2.7,2), rotation = -7, collider = "box")

rivINT.visible = False

ctrls = Text(text = "w, a, s, d\nto move\nE to use", position = (-.87, 0, 0))

RB = Entity(model = "quad", texture = "Button.png", position = (0,-2,0))

RBint = Entity(model = "quad", position = (0,-2,0), scale = .001)

Text1 = Text(text = "Press E to Launch", color = color.red, position = (-.1,-.3,0))
zombie1 = Entity(model = "quad", texture = "Zsprite.png", position = (100,100,100), scale = 2, collider = "")

#fucntions to change scene

def redPF1():
    global viewwidth1, viewwidth2, speed2, speed3, pTxTr1, pTxTr2, pTxTr3, pTxTr4, useKey
    
    player.visible=True
    level1map.texture = "level3map.png"
    rivINT.position = (0,5,0)
    rivINT.rotation = 0
    viewwidth1 = 4
    viewwidth2 = -4
    
    speed3 = 0
    speed2 = 0
    
    speed = 3.2
    speed1 = 3.2
    
    pTxTr1 = "soldierZ1.png"
    pTxTr2 = "soldierZ1.png"
    pTxTr3 = "soldierZ1.png"
    pTxTr4 = "soldierZ1.png"
    
    useKey = 0
    
    player.position = (-3,0,0)
    zombie1.position = (6,0,0)

    ctrls.text =  "w, s\nto move\nE to use/shoot"
    
def redP():
    
    player.visible=False
    tree.visible=False
    RB.visible=False
    Text1.visible=False
            
    level1map.scale = 9
    level1map.position=(0,0,1)
    level1map.texture = "RedP.png"
    
    
    
    invoke(redPF1, delay = 5)
    

app.run()


